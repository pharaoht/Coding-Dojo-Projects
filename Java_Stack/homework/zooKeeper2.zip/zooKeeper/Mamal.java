package Java_Stack.homework.zooKeeper;

public class Mamal {
    public int energy = 100;

    public Mamal() {

    }

    public void energyLevel() {

    }

    public void displayEnergy() {
        // return engery level and display
    }

}

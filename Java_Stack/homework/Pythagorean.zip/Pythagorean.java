package Java_Stack.homework;

import java.lang.Math;

public class Pythagorean {

    public double calculateHypotenuse(int legA, int legB) {

        Double a = Math.sqrt(legA);
        Double b = Math.sqrt(legB);
        Double sum = a + b;
        return sum;
    }

    public static void main(String[] args) {

    }
}

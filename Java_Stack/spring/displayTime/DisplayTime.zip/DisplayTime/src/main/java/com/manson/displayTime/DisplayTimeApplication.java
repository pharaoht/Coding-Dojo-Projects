package com.manson.displayTime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisplayTimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisplayTimeApplication.class, args);
	}

}

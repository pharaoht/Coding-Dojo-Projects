print("Hello World")

first_name = "Pharaoh"
print("Hello", first_name)

first_name = "Pharaoh"
print("hello " + first_name)

num = 20
print("hello", num)

num = "20"
print("hello " + num)

favfood1 = "pizza"
favfood2 = "pasta"
favfood3 = "wings"
print("I love to eat {} , {} , and {}".format(favfood1, favfood2, favfood3))

favfood1 = "pizza"
favfood2 = "pasta"
favfood3 = "wings"
print(f"I love to eat {favfood1} , {favfood2} , and {favfood3}")


message = "good luck with all your chores"

print(message.upper())

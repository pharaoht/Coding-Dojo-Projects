from django.apps import AppConfig


class DjangoAppTvshowsConfig(AppConfig):
    name = 'django_app_tvshows'

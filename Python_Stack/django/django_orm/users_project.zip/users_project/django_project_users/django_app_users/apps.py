from django.apps import AppConfig


class DjangoAppUsersConfig(AppConfig):
    name = 'django_app_users'

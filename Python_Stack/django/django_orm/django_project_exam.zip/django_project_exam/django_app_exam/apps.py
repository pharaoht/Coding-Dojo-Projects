from django.apps import AppConfig


class DjangoAppExamConfig(AppConfig):
    name = 'django_app_exam'

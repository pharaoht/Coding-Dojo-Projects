from django.apps import AppConfig


class DjangoAppLoginConfig(AppConfig):
    name = 'django_app_login'

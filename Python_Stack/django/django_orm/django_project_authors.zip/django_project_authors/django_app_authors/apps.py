from django.apps import AppConfig


class DjangoAppAuthorsConfig(AppConfig):
    name = 'django_app_authors'

import logo from './logo.svg';
import './App.css';
import Todolist from './components/Todolist';

function App() {
  return (
    <div className="container">
     <Todolist></Todolist>
    </div>
  );
}

export default App;

import React, {useState, useEffect} from 'react'


const StarWarsAPI = () =>{

}

export default StarWarsAPI;
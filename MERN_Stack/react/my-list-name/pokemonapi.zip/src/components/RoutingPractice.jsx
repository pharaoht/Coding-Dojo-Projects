import React from 'react'

const RoutingPracticePage1 = (props) => {

    return (
    <>
        <div><h1>Welcome</h1></div>
    </>
    )
}

export default RoutingPracticePage1;
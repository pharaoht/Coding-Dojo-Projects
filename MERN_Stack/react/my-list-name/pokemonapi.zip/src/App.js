import logo from './logo.svg';
import './App.css';
import {Router} from '@reach/router';
import StarWarsAPI from './components/StarwarsAPI';
import PokemonAxios from './components/AxiosPokemon';




function App() {
  return (
   
    <PokemonAxios></PokemonAxios>
  );
}

export default App;

import logo from './logo.svg';
import './App.css';
import Pokemonapi from './components/Pokemonapi';


function App() {
  return (
    <div className="container">
     <Pokemonapi></Pokemonapi>
    </div>
  );
}

export default App;

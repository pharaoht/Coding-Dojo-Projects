import logo from './logo.svg';
import './App.css';
import PersonCardFunctional from './components/PersonCardFunctional'

function App() {
  return (
    <div className="App">
      <PersonCardFunctional firstName={"John"} lastName={"Smith"} age={34} hairColor={"black"}></PersonCardFunctional>
      <PersonCardFunctional firstName={"Mike"} lastName={"Smith"} age={12} hairColor={"yellow"}></PersonCardFunctional>
      <PersonCardFunctional firstName={"Sara"} lastName={"Kyle"} age={33} hairColor={"Green"}></PersonCardFunctional>
      <PersonCardFunctional firstName={"Jake"} lastName={"Sam"} age={54} hairColor={"Brown"}></PersonCardFunctional>
    </div>
  );
}

export default App;

import logo from './logo.svg';
import './App.css';
import HookFormAssignment from './components/HookFormAssignment'

function App() {
  return (
    <div className="container">
      <HookFormAssignment></HookFormAssignment>
    </div>
  );
}

export default App;

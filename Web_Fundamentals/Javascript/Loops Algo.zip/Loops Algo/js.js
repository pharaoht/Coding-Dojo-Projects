var num = 1;
var sum = 0;
var prevNum = 0;

for(var num = 1; num <= 5; num++){
    if(num == 1){
        sum = num + 0;
    }
    else if(num == 2){
        sum = num + prevNum
     }
     else if(num == 3){
         sum = num + prevNum + 2 
     }
     else if(num == 4){
         sum = num + prevNum+ 3
     }
     else if(num == 5){
         sum = num + prevNum + 6
     }
    prevNum = num;
    console.log(num, sum)

}


for(var i = 0; i < 20; i++){
    console.log(i)
}